from django.urls import path
from . import views

app_name = 'transport'

urlpatterns = [
    path('', views.home, name='home'),

    # Admin URLs
    path('admin/register/', views.admin_register, name='admin_register'),
    path('admin/login/', views.admin_login, name='admin_login'),
    path('admin/logout/', views.admin_logout, name='admin_logout'),
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/driver_approval/', views.driver_approval, name='driver_approval'),
    path('admin/driver_removal/', views.driver_removal, name='driver_removal'),
    path('admin/map/', views.admin_map, name='admin_map'),
    path('admin/route_checkpoint/', views.route_checkpoint, name='route_checkpoint'),
    path('admin/assign_bus/', views.assign_bus, name='assign_bus'),
    path('admin/revenue/', views.revenue, name='revenue'),
    path('admin/ratings/', views.admin_ratings, name='admin_ratings'),
    path('admin/complaints/', views.admin_complaints, name='admin_complaints'),

    # Driver URLs
    path('driver/register/', views.driver_register, name='driver_register'),
    path('driver/login/', views.driver_login, name='driver_login'),
    path('driver/dashboard/', views.driver_dashboard, name='driver_dashboard'),
    path('driver/map/', views.driver_map, name='driver_map'),
    path('driver/ratings/', views.driver_ratings, name='driver_ratings'),
    path('driver/complaints/', views.driver_complaints, name='driver_complaints'),

    # Customer URLs
    path('customer/register/', views.customer_register, name='customer_register'),
    path('customer/login/', views.customer_login, name='customer_login'),
    path('customer/dashboard/', views.customer_dashboard, name='customer_dashboard'),
    path('customer/map/', views.customer_map, name='customer_map'),
    path('customer/delete_account/', views.delete_customer_account, name='delete_customer_account'),
    path('customer/rate_driver/', views.rate_driver, name='rate_driver'),
    path('customer/submit_complaint/', views.submit_complaint, name='submit_complaint'),
    path('customer/complaints/', views.customer_complaints, name='customer_complaints'),
    path('mpesa/callback/', views.mpesa_callback, name='mpesa_callback'),

]